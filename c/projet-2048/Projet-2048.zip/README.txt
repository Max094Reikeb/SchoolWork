Voici la commande à faire pour compiler le fichier code_2048.c :

gcc -W -Wall -Wextra code_2048.c -o main -lncurses

Vous pouvez ensuite lancer le jeu en faisant la commande suivante :

./main